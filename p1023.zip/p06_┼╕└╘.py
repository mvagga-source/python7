# 타입 - 숫자(정수, 실수), 
# 문자열, 
# 불-boolean(참, 거짓)

print(100+100)

num = "100"
num2 = 100 # 숫자 - 정수
num3 = 100.3 # 숫자 - 실수
num4 = True # 소문자 true 는 에러
num5 = False


# print("100"+100) # 문자열, 숫자는 덧셈이 안됨