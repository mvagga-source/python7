prnt("Hello Python")

print("Hello!"*3)
print("혼자 공부하다 모르면 동영상 강의를 참고하세요!")